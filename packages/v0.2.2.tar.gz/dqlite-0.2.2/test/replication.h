#ifndef DQLITE_TEST_REPLICATION_H
#define DQLITE_TEST_REPLICATION_H

#include <sqlite3.h>

sqlite3_wal_replication* test_replication();

#endif /* DQLITE_TEST_REPLICATION_H */
