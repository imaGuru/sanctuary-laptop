#ifndef DQLITE_TEST_LEAK_H
#define DQLITE_TEST_LEAK_H

void test_assert_no_leaks();

#endif /* DQLITE_TEST_LEAK_H */
